package Pula.Model;

public class Temp_user {

    public int temp_UserID;
    public String temp_Fname;
    public String temp_Address;
    public String temp_mobile;

    public int getTemp_UserID() {
        return temp_UserID;
    }

    public void setTemp_UserID(int temp_UserID) {
        this.temp_UserID = temp_UserID;
    }

    public String getTemp_Fname() {
        return temp_Fname;
    }

    public void setTemp_Fname(String temp_Fname) {
        this.temp_Fname = temp_Fname;
    }

    public String getTemp_Address() {
        return temp_Address;
    }

    public void setTemp_Address(String temp_Address) {
        this.temp_Address = temp_Address;
    }

    public String getTemp_mobile() {
        return temp_mobile;
    }

    public void setTemp_mobile(String temp_mobile) {
        this.temp_mobile = temp_mobile;
    }

    public String getTemp_nic() {
        return temp_nic;
    }

    public void setTemp_nic(String temp_nic) {
        this.temp_nic = temp_nic;
    }

    public String temp_nic;
}
