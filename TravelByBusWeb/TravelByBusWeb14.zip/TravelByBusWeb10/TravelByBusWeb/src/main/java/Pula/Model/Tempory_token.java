package Pula.Model;

public class Tempory_token {


    public int temp_ID;
    public int s_ID;
    public String temp_spoint;
    public String temp_epoint;
    public String temp_qty;
    public String temp_date;
    public String temp_time;
    public int temp_price;
    public  String token_hashID;
    public String add_date;


    public int getTemp_ID() {
        return temp_ID;
    }

    public void setTemp_ID(int temp_ID) {
        this.temp_ID = temp_ID;
    }

    public int getS_ID() {
        return s_ID;
    }

    public void setS_ID(int s_ID) {
        this.s_ID = s_ID;
    }

    public String getTemp_spoint() {
        return temp_spoint;
    }

    public void setTemp_spoint(String temp_spoint) {
        this.temp_spoint = temp_spoint;
    }

    public String getTemp_epoint() {
        return temp_epoint;
    }

    public void setTemp_epoint(String temp_epoint) {
        this.temp_epoint = temp_epoint;
    }

    public String getTemp_qty() {
        return temp_qty;
    }

    public void setTemp_qty(String temp_qty) {
        this.temp_qty = temp_qty;
    }

    public String getTemp_date() {
        return temp_date;
    }

    public void setTemp_date(String temp_date) {
        this.temp_date = temp_date;
    }

    public String getTemp_time() {
        return temp_time;
    }

    public void setTemp_time(String temp_time) {
        this.temp_time = temp_time;
    }

    public int getTemp_price() {
        return temp_price;
    }

    public void setTemp_price(int temp_price) {
        this.temp_price = temp_price;
    }

    public String getToken_hashID() {
        return token_hashID;
    }

    public void setToken_hashID(String token_hashID) {
        this.token_hashID = token_hashID;
    }

    public String getAdd_date() {
        return add_date;
    }

    public void setAdd_date(String add_date) {
        this.add_date = add_date;
    }
}
